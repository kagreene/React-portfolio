import Header from '../Header.jsx';

import Footer from '../Footer.jsx';

export default function Resume() {
    return (
        <>
            <Header title="Resume" />
            {/* Add actual link to download resume*/}
            <div className="resume-content">
                <a href="../../assets/KGResume.pdf" download>
                    Download Resume
                </a>
                <h2>Proficiencies</h2>
                <ul>
                    <li>Python</li>
                    <li>JavaScript</li>
                    <li>React</li>
                    <li>SQL</li>
                    <li>TypeScript</li>
                    <li>Node.js</li>
                    <li>HTML/CSS</li>
                    {/* Add more proficiencies */}
                </ul>
            </div>
            <Footer />
        </>
    );
}


