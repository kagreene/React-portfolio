import Header from '../Header.jsx';
import Footer from '../Footer.jsx';


export default function AboutMe() {
    return (
        <>
            <Header title="About Me" />
            {/*Need to add recent photo or avatar and a short bio */}
            <div className="about-me-content">
                <img src='../../assets/AboutMePhoto.jpg' alt="photo of developer" className="about-me-photo" />
                <p>
                    FINISH ADDING BIO 
                </p>
            </div>
            <Footer />
        </>
    );
}