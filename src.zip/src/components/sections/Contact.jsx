import ContactForm from './ContactForm.jsx';
import Header from '../Header.jsx';
import Footer from '../Footer.jsx';

export default function Contact() {
    return (
        <>
            <Header title="Contact Me" />
            <div className='contact-form-container'>
                <ContactForm />
            </div>
            <Footer />
        </>
    );
}