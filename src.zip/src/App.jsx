import PortfolioContainer from './components/PortfolioContainer'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'

function App() {
  return (
    <div className="portfolio-app">
      <PortfolioContainer />

    </div>
  )
}

export default App
